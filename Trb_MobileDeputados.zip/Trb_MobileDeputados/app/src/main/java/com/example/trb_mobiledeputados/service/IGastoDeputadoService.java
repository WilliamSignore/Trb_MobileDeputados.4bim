package com.example.trb_mobiledeputados.service;

import com.example.trb_mobiledeputados.dto.GastoDeputadoDTO;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
public interface IGastoDeputadoService {

    @GET("deputados/{id}/despesas")
    Call<GastoDeputadoDTO> getGastosDeputado(@Path("id") String id);
}

