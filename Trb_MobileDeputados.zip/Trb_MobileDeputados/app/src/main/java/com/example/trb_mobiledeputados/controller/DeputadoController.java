package com.example.trb_mobiledeputados.controller;
import com.example.trb_mobiledeputados.dto.DeputadoDTO;
import com.example.trb_mobiledeputados.service.IDeputadoService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DeputadoController {

    private final IDeputadoService deputadoService;

    public DeputadoController(IDeputadoService deputadoService) {
        this.deputadoService = deputadoService;
    }

    public static void getDeputado(String deputadoId, final DeputadoCallback callback) {
        Call<DeputadoDTO> call = deputadoService.getDeputado(deputadoId);

        call.enqueue(new Callback<DeputadoDTO>() {
            @Override
            public void onResponse(Call<DeputadoDTO> call, Response<DeputadoDTO> response) {
                if (response.isSuccessful()) {
                    DeputadoDTO dto = response.body();
                    if (dto != null) {
                        callback.onSuccess(dto);
                    } else {
                        callback.onError("Resposta vazia");
                    }
                } else {
                    callback.onError("Erro na resposta: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<DeputadoDTO> call, Throwable t) {
                callback.onError("Falha na chamada: " + t.getMessage());
            }
        });
    }
    public interface DeputadoCallback {
        void onSuccess(DeputadoDTO deputadoDTO);

        void onError(String errorMessage);
    }
}


