package com.example.trb_mobiledeputados.dto;

import java.util.List;

public class ListGastoDeputadosDTO {

    private List<GastoDeputadoDTO> dados;

    public List<GastoDeputadoDTO> getDados() {
        return dados;
    }
}
