package com.example.trb_mobiledeputados.service;

import com.example.trb_mobiledeputados.dto.DeputadoDTO;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
public interface IDeputadoService {

    @GET("deputados/{id}")
    Call<DeputadoDTO> getDeputado (@Path("id")String id);
}