package com.example.trb_mobiledeputados.dto;

import java.util.List;

public class ListPartidosDTO {

    private List<PartidosDTO> dados;

    public List<PartidosDTO> getDados() {
        return dados;
    }
}
