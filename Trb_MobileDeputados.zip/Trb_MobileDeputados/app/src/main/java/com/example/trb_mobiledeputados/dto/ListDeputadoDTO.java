package com.example.trb_mobiledeputados.dto;

import java.util.List;

public class ListDeputadoDTO {

    private List <DeputadoDTO> dados;

    public List<DeputadoDTO> getDados() {
        return dados;
    }
}
