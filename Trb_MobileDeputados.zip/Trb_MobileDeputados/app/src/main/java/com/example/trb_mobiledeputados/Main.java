package com.example.trb_mobiledeputados;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.example.trb_mobiledeputados.controller.DeputadoController;
import com.example.trb_mobiledeputados.dto.DeputadoDTO;
import com.example.trb_mobiledeputados.dto.GastoDeputadoDTO;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity {

    private EditText edtDeputadoId;
    private Button btnSearch;
    private TextView tvParty, tvExpenses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deputados);

        edtDeputadoId = findViewById(R.id.edtDeputadoId);
        btnSearch = findViewById(R.id.btnSearch);
        tvParty = findViewById(R.id.tvParty);
        tvExpenses = findViewById(R.id.tvExpenses);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchDeputado();
            }
        });
    }

    private void searchDeputado() {
        String deputadoId = edtDeputadoId.getText().toString();

        DeputadoController.getDeputado(deputadoId, new DeputadoController.DeputadoCallback() {
            @Override
            public void onSuccess(DeputadoDTO deputadoDTO) {
                if (deputadoDTO != null) {
                    tvParty.setText("Partido: " + deputadoDTO.getSiglaPartido());
                    tvExpenses.setText("Gastos: " + deputadoDTO.getGastosDeputadoDTO().getTotal());
                } else {
                    tvParty.setText("Deputado não encontrado");
                    tvExpenses.setText("");
                }
            }

            @Override
            public void onError(String errorMessage) {
                tvParty.setText("Erro: " + errorMessage);
                tvExpenses.setText("");
            }
        });
    }

            @Override
            public void onFailure(Call<DeputadoDTO> call, Throwable t) {
                tvParty.setText("Erro ao buscar deputado");
                tvExpenses.setText("");
            }
        });
    }
}
