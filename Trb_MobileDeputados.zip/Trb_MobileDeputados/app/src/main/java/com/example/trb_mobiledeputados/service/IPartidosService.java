package com.example.trb_mobiledeputados.service;
import com.example.trb_mobiledeputados.dto.PartidosDTO;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
public interface IPartidosService {

    @GET("partidos/{sigla}")
    Call<PartidosDTO> getPartidos(@Path("sigla") String sigla);
}

