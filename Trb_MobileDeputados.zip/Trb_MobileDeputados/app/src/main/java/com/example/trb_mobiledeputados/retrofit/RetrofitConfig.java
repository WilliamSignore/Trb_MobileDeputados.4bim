package com.example.trb_mobiledeputados.retrofit;

import com.example.trb_mobiledeputados.service.IDeputadoService;
import com.example.trb_mobiledeputados.service.IGastoDeputadoService;
import com.example.trb_mobiledeputados.service.IPartidosService;

import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;
public class RetrofitConfig {

    private Retrofit retrofit;
    private static final String BASE_URL = "https://dadosabertos.camara.leg.br/swagger/api.html#api";


    public RetrofitConfig(){
        this.retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(JacksonConverterFactory.create())
                .build();
    }

    public IDeputadoService deputadoService(){
        return this.retrofit.create(IDeputadoService.class);
    }
  public IGastoDeputadoService gastoDeputadoService(){
        return this.retrofit.create(IGastoDeputadoService.class);
  }
  public IPartidosService partidosService (){
        return this.retrofit.create(IPartidosService.class);
  }

}
